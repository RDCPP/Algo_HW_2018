public class Tree{
    public int size;
    public Node root;
    public Tree(Node n){
        size = 1;
        root = n;
    }
}